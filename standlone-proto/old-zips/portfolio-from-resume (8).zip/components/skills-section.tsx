"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Code, Database, Wrench, Brain, Sparkles, Rocket } from "lucide-react"
import { useTheme } from "@/components/theme-provider"
import { ScrollReveal } from "./scroll-reveal"

const skillCategories = [
  {
    title: "Languages I Speak",
    icon: Code,
    color: "primary",
    skills: ["Python", "JavaScript", "Java", "C", "HTML/CSS"],
  },
  {
    title: "AI & ML Magic",
    icon: Brain,
    color: "secondary",
    skills: ["Deep Learning", "NLP", "Computer Vision", "Data Analysis", "Prompt Engineering"],
  },
  {
    title: "Tools & Toys",
    icon: Wrench,
    color: "accent",
    skills: ["Power BI", "Tableau", "Docker", "Git", "n8n"],
  },
  {
    title: "Databases",
    icon: Database,
    color: "secondary",
    skills: ["MySQL", "MongoDB", "PostgreSQL"],
  },
  {
    title: "Web Stuff",
    icon: Sparkles,
    color: "primary",
    skills: ["React", "Node.js", "RESTful APIs", "Responsive Design"],
  },
  {
    title: "Other Cool Things",
    icon: Rocket,
    color: "accent",
    skills: ["System Design", "Parallel Programming", "OAuth 2.0", "Project Management"],
  },
]

export function SkillsSection() {
  const { theme } = useTheme()

  return (
    <section id="skills" className="py-24 bg-card">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <ScrollReveal animation={theme === "dark" ? "build" : "slide"}>
            <div className="mb-16 text-center">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
                <span className="text-foreground">My </span>
                <span className={`text-primary ${theme === "dark" ? "neon-glow" : ""}`}>toolbox</span>
              </h2>
              <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
                The tech stack that pays my bills (well, will pay my bills soon). Always adding more to the collection.
              </p>
            </div>
          </ScrollReveal>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skillCategories.map((category, index) => {
              const Icon = category.icon
              return (
                <ScrollReveal
                  key={index}
                  animation={theme === "dark" ? "puzzle" : theme === "light" ? "explode" : "slide"}
                  delay={index * 80}
                >
                  <Card
                    className={`group border-2 border-border hover:border-primary bg-background hover:shadow-2xl transition-all duration-300 cursor-pointer ${
                      theme === "dark"
                        ? "hover:scale-110 hover:shadow-primary/30 animate-multi-glow particle-trail"
                        : "hover:scale-105 hover:-translate-y-2 hover:shadow-primary/20"
                    }`}
                  >
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-3 mb-6">
                        <div
                          className={`p-3 rounded-2xl bg-${category.color}/10 group-hover:bg-${category.color}/20 transition-all ${
                            theme === "dark"
                              ? "group-hover:scale-125 group-hover:rotate-12 holographic"
                              : "group-hover:scale-110 group-hover:rotate-6"
                          }`}
                        >
                          <Icon className={`h-6 w-6 text-${category.color}`} />
                        </div>
                        <h3
                          className={`text-xl font-bold text-foreground group-hover:text-primary transition-colors ${
                            theme === "dark" ? "group-hover:neon-glow" : ""
                          }`}
                        >
                          {category.title}
                        </h3>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {category.skills.map((skill, skillIndex) => (
                          <Badge
                            key={skillIndex}
                            className={`bg-muted hover:bg-primary hover:text-primary-foreground transition-all cursor-pointer ${
                              theme === "dark"
                                ? "hover:scale-110 hover:shadow-lg hover:shadow-primary/50"
                                : "hover:scale-110"
                            }`}
                          >
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </ScrollReveal>
              )
            })}
          </div>

          <div className="mt-16 grid md:grid-cols-2 gap-8">
            <ScrollReveal animation={theme === "dark" ? "puzzle" : "slide"} delay={500}>
              <Card
                className={`border-2 border-border hover:border-primary bg-gradient-to-br from-primary/5 to-transparent transition-all ${
                  theme === "dark" ? "hover:scale-105 animate-multi-glow" : "hover:scale-105"
                }`}
              >
                <CardContent className="pt-8">
                  <h3 className={`text-2xl font-bold mb-6 text-foreground ${theme === "dark" ? "neon-glow" : ""}`}>
                    I can talk in
                  </h3>
                  <div className="space-y-4">
                    {[
                      { lang: "English", level: "Fluent" },
                      { lang: "Telugu", level: "Native" },
                      { lang: "Kannada", level: "Fluent" },
                      { lang: "Hindi", level: "Fluent" },
                    ].map((item, i) => (
                      <div key={i} className="flex justify-between items-center group cursor-pointer">
                        <span className="text-lg text-foreground/80 group-hover:text-primary transition-colors">
                          {item.lang}
                        </span>
                        <Badge
                          className={`bg-primary/20 hover:bg-primary hover:text-primary-foreground transition-all ${
                            theme === "dark" ? "hover:shadow-lg hover:shadow-primary/50" : ""
                          }`}
                        >
                          {item.level}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </ScrollReveal>

            <ScrollReveal animation={theme === "dark" ? "puzzle" : "slide"} delay={600}>
              <Card
                className={`border-2 border-border hover:border-secondary bg-gradient-to-br from-secondary/5 to-transparent transition-all ${
                  theme === "dark" ? "hover:scale-105 animate-multi-glow" : "hover:scale-105"
                }`}
              >
                <CardContent className="pt-8">
                  <h3 className={`text-2xl font-bold mb-6 text-foreground ${theme === "dark" ? "neon-glow" : ""}`}>
                    When I'm not coding
                  </h3>
                  <div className="space-y-4 text-foreground/70">
                    <div className="group cursor-pointer hover:text-primary transition-colors">
                      <div className="font-semibold mb-1 text-foreground group-hover:text-primary">Sports Junkie</div>
                      <div className="text-sm">Cricket, Football, Tennis, Chess, Swimming - you name it</div>
                    </div>
                    <div className="group cursor-pointer hover:text-primary transition-colors">
                      <div className="font-semibold mb-1 text-foreground group-hover:text-primary">Gamer</div>
                      <div className="text-sm">Assassin's Creed, Asphalt, Clash of Clans</div>
                    </div>
                    <div className="group cursor-pointer hover:text-primary transition-colors">
                      <div className="font-semibold mb-1 text-foreground group-hover:text-primary">Creative Outlet</div>
                      <div className="text-sm">Music, singing, and creating content</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </ScrollReveal>
          </div>
        </div>
      </div>
    </section>
  )
}
