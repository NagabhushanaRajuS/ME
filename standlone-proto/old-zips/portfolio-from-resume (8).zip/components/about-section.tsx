"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Rocket, Code2, Brain, Zap } from "lucide-react"
import { useTheme } from "@/components/theme-provider"

const highlights = [
  {
    icon: Brain,
    title: "AI Enthusiast",
    description: "Building multimodal systems that combine vision, language, and data",
  },
  {
    icon: Code2,
    title: "Full-Stack Dev",
    description: "From React frontends to Node backends, I enjoy the whole stack",
  },
  {
    icon: Zap,
    title: "Fast Learner",
    description: "Pick up new tech quickly and love experimenting with latest tools",
  },
  {
    icon: Rocket,
    title: "Product-Minded",
    description: "Care about building things people actually want to use",
  },
]

export function AboutSection() {
  const { theme } = useTheme()

  return (
    <section id="about" className="py-24 bg-card">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              <span className="text-foreground">A bit </span>
              <span className={`text-primary ${theme === "dark" ? "neon-glow" : ""}`}>about me</span>
            </h2>
            <div className="max-w-3xl mx-auto space-y-4 text-lg text-foreground/70 leading-relaxed">
              <p>
                I'm Nagabhushana Raju S, in my final year of Computer Science at MITM, specializing in Data Science. But
                honestly, I spend more time building stuff than sitting in lectures.
              </p>
              <p>
                My thing is taking complex ML models and making them actually useful. Whether it's detecting diseases
                from medical images or translating sign language in real-time, I love the challenge of turning research
                into reality.
              </p>
              <p>
                When I'm not coding, you'll find me playing cricket, gaming (shoutout to Assassin's Creed), or learning
                something random on YouTube.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {highlights.map((item, index) => {
              const Icon = item.icon
              return (
                <Card
                  key={index}
                  className={`group border-2 border-border hover:border-primary bg-background hover:bg-primary/5 transition-all duration-300 cursor-pointer hover-3d ${
                    theme === "dark"
                      ? "hover:scale-110 hover:rotate-2 animate-pulse-glow"
                      : theme === "light"
                        ? "hover:scale-125 hover:-translate-y-4 hover-bounce project-card"
                        : "hover:scale-105 hover:-translate-y-2"
                  }`}
                >
                  <CardContent className="pt-6">
                    <div
                      className={`mb-4 inline-flex p-3 rounded-2xl bg-primary/10 group-hover:bg-primary/20 transition-all ${
                        theme === "light"
                          ? "group-hover:scale-150 group-hover:rotate-[360deg] animate-liquid"
                          : "group-hover:scale-110"
                      }`}
                    >
                      <Icon className="w-8 h-8 text-primary" />
                    </div>
                    <h3
                      className={`text-xl font-bold mb-2 text-foreground group-hover:text-primary transition-colors ${
                        theme === "dark" ? "group-hover:neon-glow" : ""
                      }`}
                    >
                      {item.title}
                    </h3>
                    <p className="text-foreground/60 leading-relaxed">{item.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center group cursor-pointer">
              <div
                className={`stat-number text-5xl font-bold text-primary mb-2 transition-transform ${
                  theme === "dark"
                    ? "group-hover:scale-125 group-hover:neon-glow"
                    : theme === "light"
                      ? "group-hover:scale-150"
                      : "group-hover:scale-110"
                }`}
              >
                15+
              </div>
              <div className="text-sm text-foreground/60">Projects Shipped</div>
            </div>
            <div className="text-center group cursor-pointer">
              <div
                className={`stat-number text-5xl font-bold text-secondary mb-2 transition-transform ${
                  theme === "dark"
                    ? "group-hover:scale-125 group-hover:neon-glow"
                    : theme === "light"
                      ? "group-hover:scale-150"
                      : "group-hover:scale-110"
                }`}
              >
                10+
              </div>
              <div className="text-sm text-foreground/60">Certifications</div>
            </div>
            <div className="text-center group cursor-pointer">
              <div
                className={`stat-number text-5xl font-bold text-primary mb-2 transition-transform ${
                  theme === "dark"
                    ? "group-hover:scale-125 group-hover:neon-glow"
                    : theme === "light"
                      ? "group-hover:scale-150"
                      : "group-hover:scale-110"
                }`}
              >
                3
              </div>
              <div className="text-sm text-foreground/60">Internships</div>
            </div>
            <div className="text-center group cursor-pointer">
              <div
                className={`stat-number text-5xl font-bold text-secondary mb-2 transition-transform ${
                  theme === "dark"
                    ? "group-hover:scale-125 group-hover:neon-glow"
                    : theme === "light"
                      ? "group-hover:scale-150"
                      : "group-hover:scale-110"
                }`}
              >
                100%
              </div>
              <div className="text-sm text-foreground/60">Passion</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
