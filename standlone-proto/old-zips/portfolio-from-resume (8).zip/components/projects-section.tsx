"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Github, ExternalLink, Brain, Hand, Wallet, Car } from "lucide-react"
import { useTheme } from "@/components/theme-provider"
import { ScrollReveal } from "./scroll-reveal"

const projects = [
  {
    title: "Multimodal AI Disease Detector",
    description:
      "Healthcare AI that doesn't suck. Combined medical images, patient records, and genetic data to spot diseases early. Used ResNet for vision and BERT for text - basically teaching computers to think like doctors.",
    icon: Brain,
    tags: ["Python", "Deep Learning", "Healthcare", "Data Fusion"],
    gradient: "from-primary/20 to-primary/5",
    github: "https://github.com/Nagabhushanaraju",
  },
  {
    title: "Sign Language Translator",
    description:
      "Real-time sign language interpretation with computer vision. Streams results to a web frontend with overlays. Built the whole pipeline from scratch - camera to screen in milliseconds.",
    icon: Hand,
    tags: ["Computer Vision", "Real-time", "JavaScript", "AI"],
    gradient: "from-secondary/20 to-secondary/5",
    github: "https://github.com/Nagabhushanaraju",
  },
  {
    title: "Smart Expense Tracker",
    description:
      "Track your money without the headache. Built with React, features slick charts, category tags, and actually useful insights. Local storage means your data stays yours.",
    icon: Wallet,
    tags: ["React", "Charts", "Local Storage"],
    gradient: "from-accent/20 to-accent/5",
    github: "https://github.com/Nagabhushanaraju",
  },
  {
    title: "Ola Electric Clone",
    description:
      "Full-stack EV platform clone. Vehicle listings, test drives, service bookings, charging stations - the whole nine yards. Plus an admin panel because every good app needs one.",
    icon: Car,
    tags: ["Full-Stack", "React", "Node.js", "MongoDB"],
    gradient: "from-secondary/20 to-secondary/5",
    github: "https://github.com/Nagabhushanaraju",
  },
]

export function ProjectsSection() {
  const { theme } = useTheme()

  return (
    <section id="projects" className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <ScrollReveal animation={theme === "dark" ? "build" : "slide"}>
            <div className="mb-16 text-center">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
                <span className="text-foreground">Stuff I've </span>
                <span className={`text-primary ${theme === "dark" ? "neon-glow" : ""}`}>built</span>
              </h2>
              <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
                From AI healthcare systems to full-stack web apps. Here's what happens when I have too much coffee and
                an idea.
              </p>
            </div>
          </ScrollReveal>

          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, index) => {
              const Icon = project.icon
              return (
                <ScrollReveal
                  key={index}
                  animation={theme === "dark" ? "puzzle" : theme === "light" ? "explode" : "slide"}
                  delay={index * 100}
                >
                  <Card
                    className={`project-card group border-2 border-border hover:border-primary bg-gradient-to-br ${project.gradient} transition-all duration-300 cursor-pointer overflow-hidden relative hover-3d ${
                      theme === "dark"
                        ? "hover:scale-110 hover:rotate-2 animate-multi-glow particle-trail"
                        : theme === "light"
                          ? "hover:scale-125 hover:-translate-y-4"
                          : "hover:scale-105 hover:-translate-y-2"
                    }`}
                  >
                    {theme === "dark" && (
                      <div className="absolute inset-0 holographic opacity-0 group-hover:opacity-20 transition-opacity duration-500 rounded-lg" />
                    )}
                    <div
                      className={`absolute inset-0 transition-all ${
                        theme === "dark"
                          ? "bg-primary/0 group-hover:bg-gradient-to-br group-hover:from-primary/10 group-hover:via-secondary/10 group-hover:to-accent/10"
                          : "bg-primary/0 group-hover:bg-primary/5"
                      }`}
                    />
                    <CardHeader className="relative">
                      <div className="flex items-start justify-between gap-4 mb-4">
                        <div
                          className={`p-4 bg-card rounded-2xl shadow-lg transition-all ${
                            theme === "dark"
                              ? "group-hover:scale-125 group-hover:rotate-12 animate-float holographic"
                              : theme === "light"
                                ? "group-hover:scale-150 group-hover:rotate-[360deg] animate-morph"
                                : "group-hover:scale-110 group-hover:rotate-6"
                          }`}
                        >
                          <Icon className="h-8 w-8 text-primary" />
                        </div>
                      </div>
                      <CardTitle
                        className={`text-2xl group-hover:text-primary transition-colors ${
                          theme === "dark" ? "group-hover:neon-glow" : ""
                        }`}
                      >
                        {project.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6 relative">
                      <p className="text-foreground/70 leading-relaxed text-base">{project.description}</p>

                      <div className="flex flex-wrap gap-2">
                        {project.tags.map((tag, tagIndex) => (
                          <Badge
                            key={tagIndex}
                            className={`bg-background/80 hover:bg-primary hover:text-primary-foreground transition-all border border-border ${
                              theme === "dark"
                                ? "hover:scale-110 hover:rotate-3 hover:shadow-lg hover:shadow-primary/50"
                                : theme === "light"
                                  ? "hover:scale-125 hover:rotate-6"
                                  : "hover:scale-105"
                            }`}
                          >
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex gap-3 pt-2">
                        <Button
                          size="sm"
                          className={`bg-primary hover:bg-primary/90 text-primary-foreground transition-all hover-3d ${
                            theme === "dark"
                              ? "hover:scale-110 animate-multi-glow"
                              : theme === "light"
                                ? "hover:scale-125 hover-bounce"
                                : "hover:scale-105"
                          }`}
                          asChild
                        >
                          <a href={project.github} target="_blank" rel="noopener noreferrer">
                            <Github className="h-4 w-4 mr-2" />
                            View Code
                          </a>
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className={`border-2 hover:border-primary hover:bg-primary/5 transition-all bg-transparent hover-3d ${
                            theme === "dark"
                              ? "hover:scale-110"
                              : theme === "light"
                                ? "hover:scale-125"
                                : "hover:scale-105"
                          }`}
                          asChild
                        >
                          <a href={project.github} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4 mr-2" />
                            Live Demo
                          </a>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </ScrollReveal>
              )
            })}
          </div>

          <ScrollReveal animation={theme === "dark" ? "assemble" : "slide"} delay={400}>
            <Card
              className={`mt-12 border-2 border-dashed border-primary/30 bg-gradient-to-br from-primary/5 to-secondary/5 transition-all hover-3d ${
                theme === "dark"
                  ? "hover:border-primary/70 hover:scale-105 animate-multi-glow"
                  : theme === "light"
                    ? "hover:border-primary/70 hover:scale-110 hover-bounce"
                    : "hover:border-primary/50"
              }`}
            >
              <CardContent className="pt-8">
                <h3 className="text-2xl font-bold mb-4 text-foreground">And there's more...</h3>
                <p className="text-foreground/70 leading-relaxed text-lg">
                  Chatbots with LangChain, OAuth implementations, automated email systems, GPU-accelerated projects with
                  OpenMP/MPI, cryptographic verification systems, and a bunch of experiments with UI animations.
                  Basically, if it sounds interesting, I've probably tried building it at 2 AM.
                </p>
              </CardContent>
            </Card>
          </ScrollReveal>
        </div>
      </div>
    </section>
  )
}
