"use client"

import { useEffect, useRef, useState } from "react"

interface SplitTextRevealProps {
  text: string
  className?: string
  delay?: number
}

export function SplitTextReveal({ text, className = "", delay = 0 }: SplitTextRevealProps) {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), delay)
          observer.disconnect()
        }
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [delay])

  const characters = text.split("")

  return (
    <div ref={ref} className={`inline-block ${className}`}>
      {characters.map((char, index) => (
        <span
          key={index}
          className="inline-block"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? "translateY(0)" : "translateY(20px)",
            transition: `all 0.5s cubic-bezier(0.22, 1, 0.36, 1) ${index * 0.03}s`,
          }}
        >
          {char === " " ? "\u00A0" : char}
        </span>
      ))}
    </div>
  )
}
