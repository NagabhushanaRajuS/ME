"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Briefcase, Calendar, GraduationCap } from "lucide-react"
import { useTheme } from "./theme-provider"
import { ScrollReveal } from "./scroll-reveal"
import { ParallaxSection } from "./parallax-section"

export function ExperienceSection() {
  const { theme } = useTheme()

  return (
    <section id="experience" className="py-24 bg-background relative overflow-hidden">
      {theme === "light" && (
        <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse" />
      )}

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto">
          <ScrollReveal animation={theme === "dark" ? "build" : "slide"}>
            <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center">
              <span className="text-foreground">Work </span>
              <span className={`text-primary ${theme === "dark" ? "neon-glow" : ""}`}>Experience</span>
            </h2>
          </ScrollReveal>

          <ParallaxSection speed={0.3}>
            <ScrollReveal animation={theme === "dark" ? "puzzle" : "slide"} delay={200}>
              <Card
                className={`border-2 hover:border-primary transition-all duration-500 hover-3d ${
                  theme === "dark"
                    ? "hover:scale-105 animate-multi-glow holographic"
                    : theme === "light"
                      ? "hover:scale-110 hover:-translate-y-4"
                      : "hover:scale-105"
                } bg-card/80 backdrop-blur-sm`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div className="flex items-center gap-3">
                      <div
                        className={`p-2 bg-primary/10 rounded-lg transition-all ${
                          theme === "dark" ? "hover:scale-125 hover:rotate-12 animate-float" : "hover:scale-110"
                        }`}
                      >
                        <Briefcase className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <CardTitle
                          className={`text-xl ${theme === "dark" ? "group-hover:neon-glow" : ""} transition-colors`}
                        >
                          Software Development Intern
                        </CardTitle>
                        <CardDescription className="text-base">
                          Getskilled (A unit of GyaanKool Research labs)
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground shrink-0">
                      <Calendar className="h-4 w-4" />
                      Apr 2025 – Aug 2025
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground leading-relaxed">
                    My first internship was a transformative experience, offering both technical depth and collaborative
                    exposure. Worked in a hybrid setup with weekly on-site visits and daily virtual meetings.
                  </p>

                  <div className="space-y-3">
                    <div className="flex gap-3 group cursor-pointer hover:translate-x-2 transition-transform">
                      <div className="w-1.5 bg-primary rounded-full mt-1.5 shrink-0 group-hover:bg-secondary transition-colors" />
                      <p className="text-muted-foreground group-hover:text-foreground transition-colors">
                        Engineered data pipelines for multimodal inputs, leveraging{" "}
                        <span className="text-foreground font-medium">ResNet</span> for medical imaging and{" "}
                        <span className="text-foreground font-medium">BERT</span> for clinical text
                      </p>
                    </div>
                    <div className="flex gap-3 group cursor-pointer hover:translate-x-2 transition-transform">
                      <div className="w-1.5 bg-primary rounded-full mt-1.5 shrink-0 group-hover:bg-secondary transition-colors" />
                      <p className="text-muted-foreground group-hover:text-foreground transition-colors">
                        Implemented and benchmarked fusion models to optimize diagnostic precision across modalities
                      </p>
                    </div>
                    <div className="flex gap-3 group cursor-pointer hover:translate-x-2 transition-transform">
                      <div className="w-1.5 bg-primary rounded-full mt-1.5 shrink-0 group-hover:bg-secondary transition-colors" />
                      <p className="text-muted-foreground group-hover:text-foreground transition-colors">
                        Successfully developed a multimodal ML system for early disease detection
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 pt-4">
                    {["Python", "Machine Learning", "ResNet", "BERT", "Data Pipelines", "Healthcare AI"].map(
                      (tech, i) => (
                        <Badge
                          key={i}
                          className={`transition-all ${
                            theme === "dark"
                              ? "hover:scale-110 hover:shadow-lg hover:shadow-primary/50"
                              : "hover:scale-110"
                          }`}
                        >
                          {tech}
                        </Badge>
                      ),
                    )}
                  </div>
                </CardContent>
              </Card>
            </ScrollReveal>
          </ParallaxSection>

          <ScrollReveal animation={theme === "dark" ? "puzzle" : "slide"} delay={400}>
            <div
              className={`mt-8 p-6 bg-gradient-to-br from-muted/80 to-muted/40 rounded-lg border border-border backdrop-blur-sm transition-all hover:border-primary ${
                theme === "dark" ? "hover:scale-105 animate-multi-glow" : "hover:scale-105"
              }`}
            >
              <div className="flex items-center gap-3 mb-4">
                <div
                  className={`p-2 bg-primary/10 rounded-lg ${theme === "dark" ? "hover:scale-110 hover:rotate-12" : ""} transition-all`}
                >
                  <GraduationCap className="h-6 w-6 text-primary" />
                </div>
                <h3 className={`text-xl font-semibold ${theme === "dark" ? "neon-glow" : ""}`}>Education</h3>
              </div>
              <div className="space-y-4">
                <div className="group cursor-pointer hover:translate-x-2 transition-transform">
                  <div className="flex items-start justify-between gap-4 mb-2 flex-wrap">
                    <div>
                      <h4 className="font-medium text-lg group-hover:text-primary transition-colors">
                        B.E. Computer Science & Engineering (Data Science)
                      </h4>
                      <p className="text-sm text-muted-foreground">Maharaja Institute of Technology Mysuru (MITM)</p>
                    </div>
                    <span className="text-sm text-muted-foreground shrink-0">Expected Jun 2026</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    GPA: 7.2 (Improved from 6.6—demonstrating consistent upward trend) • 7th Semester Ongoing
                  </p>
                </div>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  )
}
