"use client"

import { useEffect, useState } from "react"
import { useTheme } from "./theme-provider"

export function ScrollProgress() {
  const [progress, setProgress] = useState(0)
  const { theme } = useTheme()

  useEffect(() => {
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight
      const scrolled = (window.scrollY / totalHeight) * 100
      setProgress(scrolled)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const getGradient = () => {
    switch (theme) {
      case "light":
        return "linear-gradient(90deg, #73b446, #e6b450)"
      case "mild":
        return "linear-gradient(90deg, #c86450, #50b4b4, #dc508c)"
      case "dark":
        return "linear-gradient(90deg, #a064e6, #64c8e6, #e664c8)"
      default:
        return "linear-gradient(90deg, #60a5fa, #a78bfa)"
    }
  }

  return (
    <div
      className="fixed top-0 left-0 h-1 z-50 transition-all duration-300"
      style={{
        width: `${progress}%`,
        background: getGradient(),
        boxShadow: `0 0 10px ${theme === "dark" ? "rgba(160, 100, 230, 0.8)" : "rgba(115, 180, 70, 0.6)"}`,
      }}
    />
  )
}
