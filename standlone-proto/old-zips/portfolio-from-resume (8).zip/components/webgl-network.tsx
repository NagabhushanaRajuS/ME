"use client"

import { useEffect, useRef } from "react"
import { useTheme } from "./theme-provider"

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  connections: number[]
}

export function WebGLNetwork() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { theme } = useTheme()
  const mouseRef = useRef({ x: 0, y: 0 })
  const particlesRef = useRef<Particle[]>([])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Initialize particles
    const particleCount = 80
    particlesRef.current = Array.from({ length: particleCount }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.5,
      connections: [],
    }))

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = { x: e.clientX, y: e.clientY }
    }

    window.addEventListener("mousemove", handleMouseMove)

    const getColors = () => {
      switch (theme) {
        case "light":
          return {
            particle: "rgba(115, 180, 70, 0.8)",
            line: "rgba(230, 180, 80, 0.3)",
            glow: "rgba(115, 180, 70, 0.6)",
          }
        case "mild":
          return {
            particle: "rgba(200, 100, 80, 0.7)",
            line: "rgba(80, 180, 180, 0.3)",
            glow: "rgba(220, 80, 140, 0.5)",
          }
        case "dark":
          return {
            particle: "rgba(160, 100, 230, 0.9)",
            line: "rgba(100, 200, 230, 0.4)",
            glow: "rgba(230, 100, 200, 0.7)",
          }
        default:
          return {
            particle: "rgba(100, 200, 255, 0.8)",
            line: "rgba(100, 200, 255, 0.2)",
            glow: "rgba(100, 200, 255, 0.6)",
          }
      }
    }

    let animationId: number

    const animate = () => {
      ctx.fillStyle = "rgba(0, 0, 0, 0.05)"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      const colors = getColors()
      const particles = particlesRef.current

      // Update and draw particles
      particles.forEach((particle, i) => {
        // Move particle
        particle.x += particle.vx
        particle.y += particle.vy

        // Bounce off edges
        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1

        // Mouse interaction
        const dx = mouseRef.current.x - particle.x
        const dy = mouseRef.current.y - particle.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < 150) {
          particle.x -= dx * 0.01
          particle.y -= dy * 0.01
        }

        // Draw connections
        particles.forEach((otherParticle, j) => {
          if (i === j) return

          const dx = otherParticle.x - particle.x
          const dy = otherParticle.y - particle.y
          const dist = Math.sqrt(dx * dx + dy * dy)

          if (dist < 120) {
            ctx.strokeStyle = colors.line
            ctx.lineWidth = 1
            ctx.beginPath()
            ctx.moveTo(particle.x, particle.y)
            ctx.lineTo(otherParticle.x, otherParticle.y)
            ctx.stroke()
          }
        })

        // Draw particle with glow
        ctx.shadowBlur = 20
        ctx.shadowColor = colors.glow
        ctx.fillStyle = colors.particle
        ctx.beginPath()
        ctx.arc(particle.x, particle.y, 3, 0, Math.PI * 2)
        ctx.fill()
        ctx.shadowBlur = 0
      })

      animationId = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
      window.removeEventListener("mousemove", handleMouseMove)
      cancelAnimationFrame(animationId)
    }
  }, [theme])

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0" style={{ opacity: 0.6 }} />
}
