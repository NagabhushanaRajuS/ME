"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"

interface ScrollRevealProps {
  children: React.ReactNode
  className?: string
  animation?: "fade" | "slide" | "puzzle" | "build" | "explode"
  delay?: number
}

export function ScrollReveal({ children, className = "", animation = "fade", delay = 0 }: ScrollRevealProps) {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => {
            setIsVisible(true)
          }, delay)
        }
      },
      {
        threshold: 0.1,
      },
    )

    const currentRef = ref.current
    if (currentRef) {
      observer.observe(currentRef)
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef)
      }
    }
  }, [delay])

  const getAnimationClass = () => {
    if (!isVisible) {
      switch (animation) {
        case "slide":
          return "opacity-0 translate-y-20"
        case "puzzle":
          return "opacity-0 scale-50 rotate-45"
        case "build":
          return "opacity-0 scale-0"
        case "explode":
          return "opacity-0 scale-150"
        default:
          return "opacity-0"
      }
    }

    switch (animation) {
      case "slide":
        return "opacity-100 translate-y-0"
      case "puzzle":
        return "opacity-100 scale-100 rotate-0"
      case "build":
        return "opacity-100 scale-100"
      case "explode":
        return "opacity-100 scale-100"
      default:
        return "opacity-100"
    }
  }

  return (
    <div ref={ref} className={`transition-all duration-1000 ease-out ${getAnimationClass()} ${className}`}>
      {children}
    </div>
  )
}
