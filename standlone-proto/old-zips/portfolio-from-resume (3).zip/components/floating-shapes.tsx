"use client"

import { useEffect, useState } from "react"
import { useTheme } from "./theme-provider"

export function FloatingShapes() {
  const [mounted, setMounted] = useState(false)
  const { theme } = useTheme()

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const shapes = theme === "dark" ? 8 : theme === "mild" ? 6 : 4

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none" style={{ zIndex: 1 }}>
      {Array.from({ length: shapes }).map((_, i) => {
        const size = Math.random() * 200 + 100
        const left = Math.random() * 100
        const top = Math.random() * 100
        const delay = Math.random() * 10
        const duration = theme === "dark" ? 15 + Math.random() * 10 : 25 + Math.random() * 15

        const shapeType = i % 3

        return (
          <div
            key={i}
            className={`absolute blur-3xl opacity-20 ${theme === "dark" ? "animate-pulse-glow" : ""}`}
            style={{
              width: `${size}px`,
              height: `${size}px`,
              left: `${left}%`,
              top: `${top}%`,
              animationDelay: `${delay}s`,
              animationDuration: `${duration}s`,
              background:
                theme === "dark"
                  ? shapeType === 0
                    ? "radial-gradient(circle, oklch(0.65 0.25 145) 0%, transparent 70%)"
                    : shapeType === 1
                      ? "radial-gradient(circle, oklch(0.85 0.18 95) 0%, transparent 70%)"
                      : "radial-gradient(circle, oklch(0.65 0.25 145) 0%, transparent 70%)"
                  : theme === "mild"
                    ? shapeType === 0
                      ? "radial-gradient(circle, oklch(0.55 0.22 280) 0%, transparent 70%)"
                      : shapeType === 1
                        ? "radial-gradient(circle, oklch(0.65 0.18 340) 0%, transparent 70%)"
                        : "radial-gradient(circle, oklch(0.7 0.2 180) 0%, transparent 70%)"
                    : shapeType === 0
                      ? "radial-gradient(circle, oklch(0.75 0.15 95) 0%, transparent 70%)"
                      : shapeType === 1
                        ? "radial-gradient(circle, oklch(0.45 0.18 145) 0%, transparent 70%)"
                        : "radial-gradient(circle, oklch(0.75 0.15 95) 0%, transparent 70%)",
            }}
          >
            <div
              className={`w-full h-full ${
                theme === "dark" ? "animate-rotate-slow" : theme === "mild" ? "animate-scale-pulse" : "animate-float"
              }`}
              style={{
                animationDuration: `${duration}s`,
              }}
            />
          </div>
        )
      })}
    </div>
  )
}
