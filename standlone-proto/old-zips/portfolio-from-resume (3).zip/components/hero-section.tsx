"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowRight, Github, Linkedin, Mail, Sparkles } from "lucide-react"
import { Hero3D } from "./hero-3d"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useTheme } from "@/components/theme-provider"

export function HeroSection() {
  const [mounted, setMounted] = useState(false)
  const { theme } = useTheme()

  useEffect(() => {
    setMounted(true)
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background">
      <div className="absolute inset-0 -z-10">
        <Hero3D />
      </div>

      <div className="container mx-auto px-4 pt-20">
        <div
          className={`max-w-5xl mx-auto transition-all duration-1000 ${
            mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <div className="flex justify-center mb-8">
            <div className="relative group">
              <div
                className={`absolute -inset-1 rounded-full blur-lg opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 ${
                  theme === "dark"
                    ? "bg-gradient-to-r from-primary via-secondary to-primary animate-pulse-glow"
                    : theme === "mild"
                      ? "bg-gradient-to-r from-primary via-accent to-secondary animate-pulse-glow-secondary"
                      : "bg-gradient-to-r from-secondary via-primary to-secondary"
                } animate-pulse`}
              ></div>
              <Avatar
                className={`relative w-32 h-32 border-4 border-background ${theme === "dark" ? "animate-float" : ""}`}
              >
                <AvatarImage src="/professional-developer-avatar.png" alt="Nagabhushana Raju" />
                <AvatarFallback className="text-3xl bg-primary text-primary-foreground">NR</AvatarFallback>
              </Avatar>
            </div>
          </div>

          <div className="text-center space-y-6">
            <div
              className={`inline-flex items-center gap-2 px-4 py-2 bg-primary/10 border-2 border-primary rounded-full text-sm font-medium text-primary mb-4 transition-all ${
                theme === "dark" ? "hover:scale-110 animate-pulse-glow" : "hover:scale-105"
              }`}
            >
              <Sparkles className={`w-4 h-4 ${theme === "dark" ? "animate-spin" : ""}`} />
              <span>Available for exciting opportunities</span>
            </div>

            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-balance leading-tight">
              <span className="text-foreground">Hey, I'm </span>
              <span
                className={`bg-gradient-to-r ${
                  theme === "dark"
                    ? "from-primary via-secondary to-primary animate-gradient"
                    : theme === "mild"
                      ? "from-primary via-accent to-secondary animate-gradient"
                      : "from-secondary via-primary to-secondary"
                } bg-clip-text text-transparent`}
              >
                Naga
              </span>
            </h1>

            <p className="text-2xl md:text-3xl font-medium text-foreground/80 text-balance">
              I build AI systems that actually work
            </p>

            <p className="text-lg md:text-xl text-foreground/60 max-w-3xl mx-auto leading-relaxed text-balance">
              From multimodal AI for healthcare to real-time sign language interpreters, I love turning complex ML
              models into products people can use. Currently finishing my CS degree and building cool stuff with Python,
              React, and whatever gets the job done.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
              <Button
                size="lg"
                className={`group bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg hover:shadow-xl transition-all ${
                  theme === "dark" ? "hover:scale-110 animate-pulse-glow" : "hover:scale-105"
                }`}
                onClick={() => scrollToSection("projects")}
              >
                See What I've Built
                <ArrowRight
                  className={`ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform ${theme === "dark" ? "animate-pulse" : ""}`}
                />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className={`border-2 border-foreground/20 hover:border-primary hover:bg-primary/5 transition-all bg-transparent ${
                  theme === "dark" ? "hover:scale-110 hover-blur" : "hover:scale-105"
                }`}
                onClick={() => scrollToSection("contact")}
              >
                Let's Talk
              </Button>
            </div>

            <div className="flex items-center justify-center gap-4 pt-8">
              <a
                href="https://github.com/Nagabhushanaraju"
                target="_blank"
                rel="noopener noreferrer"
                className={`p-3 rounded-full bg-card hover:bg-primary hover:text-primary-foreground transition-all border-2 border-border ${
                  theme === "dark"
                    ? "hover:scale-125 hover:rotate-12 animate-pulse-glow"
                    : theme === "mild"
                      ? "hover:scale-115 hover:rotate-6"
                      : "hover:scale-110 hover:rotate-6"
                }`}
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="https://www.linkedin.com/in/nagabhushana-raju-s-18b84b288"
                target="_blank"
                rel="noopener noreferrer"
                className={`p-3 rounded-full bg-card hover:bg-primary hover:text-primary-foreground transition-all border-2 border-border ${
                  theme === "dark"
                    ? "hover:scale-125 hover:rotate-12 animate-pulse-glow"
                    : theme === "mild"
                      ? "hover:scale-115 hover:rotate-6"
                      : "hover:scale-110 hover:rotate-6"
                }`}
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="mailto:nagabhushana240@gmail.com"
                className={`p-3 rounded-full bg-card hover:bg-primary hover:text-primary-foreground transition-all border-2 border-border ${
                  theme === "dark"
                    ? "hover:scale-125 hover:rotate-12 animate-pulse-glow"
                    : theme === "mild"
                      ? "hover:scale-115 hover:rotate-6"
                      : "hover:scale-110 hover:rotate-6"
                }`}
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
