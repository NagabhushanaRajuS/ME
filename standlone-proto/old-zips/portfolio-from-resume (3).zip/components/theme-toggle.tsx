"use client"

import { useTheme } from "@/components/theme-provider"
import { Sun, CloudSun, Moon } from "lucide-react"
import { Button } from "@/components/ui/button"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()

  return (
    <div className="flex items-center gap-2 p-1 bg-card/50 backdrop-blur-sm rounded-full border border-border">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setTheme("light")}
        className={`rounded-full transition-all duration-300 ${
          theme === "light" ? "bg-secondary text-secondary-foreground shadow-lg scale-110" : "hover:bg-muted"
        }`}
      >
        <Sun className="h-4 w-4" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setTheme("mild")}
        className={`rounded-full transition-all duration-300 ${
          theme === "mild" ? "bg-primary text-primary-foreground shadow-lg scale-110" : "hover:bg-muted"
        }`}
      >
        <CloudSun className="h-4 w-4" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setTheme("dark")}
        className={`rounded-full transition-all duration-300 ${
          theme === "dark" ? "bg-foreground text-background shadow-lg scale-110" : "hover:bg-muted"
        }`}
      >
        <Moon className="h-4 w-4" />
      </Button>
    </div>
  )
}
