"use client"

import { useEffect, useState } from "react"
import { useTheme } from "./theme-provider"

interface TrailPoint {
  x: number
  y: number
  timestamp: number
}

export function CursorTrail() {
  const [trails, setTrails] = useState<TrailPoint[]>([])
  const { theme } = useTheme()

  useEffect(() => {
    if (theme !== "dark") return // Only show in dark mode

    const handleMouseMove = (e: MouseEvent) => {
      const newPoint = {
        x: e.clientX,
        y: e.clientY,
        timestamp: Date.now(),
      }

      setTrails((prev) => {
        const updated = [...prev, newPoint]
        // Keep only recent trails (last 20)
        return updated.slice(-20)
      })
    }

    window.addEventListener("mousemove", handleMouseMove)

    // Clean up old trails
    const interval = setInterval(() => {
      setTrails((prev) => prev.filter((point) => Date.now() - point.timestamp < 500))
    }, 50)

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      clearInterval(interval)
    }
  }, [theme])

  if (theme !== "dark") return null

  return (
    <div className="fixed inset-0 pointer-events-none" style={{ zIndex: 9999 }}>
      {trails.map((point, index) => {
        const age = Date.now() - point.timestamp
        const opacity = 1 - age / 500
        const size = 8 - (age / 500) * 6

        return (
          <div
            key={`${point.timestamp}-${index}`}
            className="absolute rounded-full bg-gradient-to-r from-primary via-secondary to-accent blur-sm"
            style={{
              left: point.x,
              top: point.y,
              width: `${size}px`,
              height: `${size}px`,
              opacity,
              transform: "translate(-50%, -50%)",
              transition: "opacity 0.1s, width 0.1s, height 0.1s",
            }}
          />
        )
      })}
    </div>
  )
}
