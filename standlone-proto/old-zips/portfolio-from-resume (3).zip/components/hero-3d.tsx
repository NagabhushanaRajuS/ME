"use client"

import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Sphere, MeshDistortMaterial, Float } from "@react-three/drei"
import { useRef } from "react"
import type * as THREE from "three"
import { useTheme } from "@/components/theme-provider"

function AnimatedSphere() {
  const meshRef = useRef<THREE.Mesh>(null)
  const { theme } = useTheme()

  useFrame((state) => {
    if (meshRef.current) {
      const speed = theme === "dark" ? 0.3 : theme === "mild" ? 0.2 : 0.15
      meshRef.current.rotation.x = state.clock.getElapsedTime() * speed
      meshRef.current.rotation.y = state.clock.getElapsedTime() * (speed * 1.5)
    }
  })

  const sphereColor = theme === "dark" ? "#4ade80" : theme === "mild" ? "#a855f7" : "#eab308"
  const distortAmount = theme === "dark" ? 0.6 : theme === "mild" ? 0.4 : 0.3

  return (
    <Float speed={theme === "dark" ? 3 : theme === "mild" ? 2 : 1.5} rotationIntensity={0.5} floatIntensity={0.5}>
      <Sphere ref={meshRef} args={[1, 100, 100]} scale={2.5}>
        <MeshDistortMaterial
          color={sphereColor}
          attach="material"
          distort={distortAmount}
          speed={theme === "dark" ? 3 : theme === "mild" ? 2 : 1.5}
          roughness={0.2}
          metalness={0.8}
        />
      </Sphere>
    </Float>
  )
}

function FloatingCubes() {
  const cubesRef = useRef<THREE.Group>(null)
  const { theme } = useTheme()

  useFrame((state) => {
    if (cubesRef.current) {
      const rotationSpeed = theme === "dark" ? 0.15 : theme === "mild" ? 0.1 : 0.08
      cubesRef.current.rotation.y = state.clock.getElapsedTime() * rotationSpeed
    }
  })

  const colors =
    theme === "dark"
      ? { primary: "#eab308", secondary: "#4ade80", tertiary: "#f59e0b" }
      : theme === "mild"
        ? { primary: "#ec4899", secondary: "#8b5cf6", tertiary: "#06b6d4" }
        : { primary: "#22c55e", secondary: "#eab308", tertiary: "#16a34a" }

  return (
    <group ref={cubesRef}>
      <Float speed={theme === "dark" ? 2.5 : 1.5} rotationIntensity={1} floatIntensity={2}>
        <mesh position={[-3, 1, 0]}>
          <boxGeometry args={[0.5, 0.5, 0.5]} />
          <meshStandardMaterial color={colors.primary} />
        </mesh>
      </Float>
      <Float speed={theme === "dark" ? 3 : 2} rotationIntensity={1} floatIntensity={1.5}>
        <mesh position={[3, -1, 0]}>
          <boxGeometry args={[0.4, 0.4, 0.4]} />
          <meshStandardMaterial color={colors.secondary} />
        </mesh>
      </Float>
      <Float speed={theme === "dark" ? 2.8 : 1.8} rotationIntensity={0.8} floatIntensity={2}>
        <mesh position={[0, 2, -2]}>
          <boxGeometry args={[0.3, 0.3, 0.3]} />
          <meshStandardMaterial color={colors.tertiary} />
        </mesh>
      </Float>
    </group>
  )
}

export function Hero3D() {
  const { theme } = useTheme()

  const ambientIntensity = theme === "dark" ? 0.3 : theme === "mild" ? 0.5 : 0.7
  const spotIntensity = theme === "dark" ? 1.5 : theme === "mild" ? 1 : 0.8

  return (
    <div className="w-full h-full">
      <Canvas camera={{ position: [0, 0, 8], fov: 50 }}>
        <ambientLight intensity={ambientIntensity} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={spotIntensity} />
        <pointLight position={[-10, -10, -10]} intensity={0.5} />
        <AnimatedSphere />
        <FloatingCubes />
        <OrbitControls enableZoom={false} enablePan={false} />
      </Canvas>
    </div>
  )
}
