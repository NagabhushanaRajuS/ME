import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Briefcase, Calendar } from "lucide-react"

export function ExperienceSection() {
  return (
    <section id="experience" className="py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12">
            Work <span className="text-primary">Experience</span>
          </h2>

          <Card className="border-2 hover:border-primary/50 transition-colors">
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Briefcase className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Software Development Intern</CardTitle>
                    <CardDescription className="text-base">
                      Getskilled (A unit of GyaanKool Research labs)
                    </CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground shrink-0">
                  <Calendar className="h-4 w-4" />
                  Apr 2025 – Aug 2025
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                My first internship was a transformative experience, offering both technical depth and collaborative
                exposure. Worked in a hybrid setup with weekly on-site visits and daily virtual meetings.
              </p>

              <div className="space-y-3">
                <div className="flex gap-3">
                  <div className="w-1.5 bg-primary rounded-full mt-1.5 shrink-0" />
                  <p className="text-muted-foreground">
                    Engineered data pipelines for multimodal inputs, leveraging{" "}
                    <span className="text-foreground font-medium">ResNet</span> for medical imaging and{" "}
                    <span className="text-foreground font-medium">BERT</span> for clinical text
                  </p>
                </div>
                <div className="flex gap-3">
                  <div className="w-1.5 bg-primary rounded-full mt-1.5 shrink-0" />
                  <p className="text-muted-foreground">
                    Implemented and benchmarked fusion models to optimize diagnostic precision across modalities
                  </p>
                </div>
                <div className="flex gap-3">
                  <div className="w-1.5 bg-primary rounded-full mt-1.5 shrink-0" />
                  <p className="text-muted-foreground">
                    Successfully developed a multimodal ML system for early disease detection
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 pt-4">
                <Badge variant="secondary">Python</Badge>
                <Badge variant="secondary">Machine Learning</Badge>
                <Badge variant="secondary">ResNet</Badge>
                <Badge variant="secondary">BERT</Badge>
                <Badge variant="secondary">Data Pipelines</Badge>
                <Badge variant="secondary">Healthcare AI</Badge>
              </div>
            </CardContent>
          </Card>

          <div className="mt-8 p-6 bg-muted/50 rounded-lg border border-border">
            <h3 className="text-lg font-semibold mb-3">Education</h3>
            <div className="space-y-4">
              <div>
                <div className="flex items-start justify-between gap-4 mb-2">
                  <div>
                    <h4 className="font-medium">B.E. Computer Science & Engineering (Data Science)</h4>
                    <p className="text-sm text-muted-foreground">Maharaja Institute of Technology Mysuru (MITM)</p>
                  </div>
                  <span className="text-sm text-muted-foreground shrink-0">Expected Jun 2026</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  GPA: 7.2 (Improved from 6.6—demonstrating consistent upward trend) • 7th Semester Ongoing
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
