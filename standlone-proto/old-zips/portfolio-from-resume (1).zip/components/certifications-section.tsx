import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Award, BookOpen } from "lucide-react"

const certifications = [
  {
    title: "Google Advanced Data Analytics Course",
    provider: "Coursera",
    date: "Ongoing",
    status: "In Progress",
    description: "Professional-level training in advanced data analytics, statistical methods, and applied ML",
  },
  {
    title: "Advanced Statistics for Machine Learning",
    provider: "Infosys Springboard",
    date: "Dec 2025",
    status: "Completed",
  },
  {
    title: "Getting Started with Managing Remote Teams",
    provider: "Infosys Springboard",
    date: "Dec 2025",
    status: "Completed",
  },
  {
    title: "Technical Workshop on Data Science",
    provider: "IIT Hyderabad (with Elan & Envision)",
    date: "Apr 2025",
    status: "Completed",
  },
  {
    title: "Data Analytics Using Power BI – 30 Day Intensive",
    provider: "TechTip24 / Skill Course E-Learning",
    date: "Apr 2025 – May 2025",
    status: "Completed",
    description: "Comprehensive training in advanced data visualization and business intelligence",
  },
  {
    title: "Microsoft Excel Using AI Workshop",
    provider: "BE 10x | QM Office Master",
    date: "Oct 2024",
    status: "Completed",
    description: "Advanced Excel automation using AI, mastering 200+ formulas",
  },
  {
    title: "Placement Training on AIML & Data Analytics",
    provider: "Tejas PRO",
    date: "2025",
    status: "Completed",
    description: "Hands-on training in AI, ML, and Data Analytics with real-world applications",
  },
  {
    title: "Computer Applications & Programming in C",
    provider: "Indian Institute of Computer Technology (IICT)",
    date: "Jul 2022 – Sep 2022",
    status: "Completed",
  },
]

const ongoingCourses = [
  {
    title: "Python Using AI Mastery Course",
    provider: "Be10X",
  },
  {
    title: "Managing Emotions in Times of Uncertainty & Stress",
    provider: "Yale University",
  },
  {
    title: "Finding Your Professional Voice",
    provider: "University of London",
  },
  {
    title: "Mindshift: Break Through Obstacles to Learning",
    provider: "McMaster University",
  },
]

export function CertificationsSection() {
  return (
    <section id="certifications" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="mb-12 flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-lg">
              <Award className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h2 className="text-3xl md:text-4xl font-bold">
                Certifications & <span className="text-primary">Learning</span>
              </h2>
              <p className="text-muted-foreground mt-2">Continuous learning and professional development</p>
            </div>
          </div>

          <div className="space-y-6 mb-12">
            {certifications.map((cert, index) => (
              <Card key={index} className="border-2 hover:border-primary/50 transition-colors">
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <CardTitle className="text-lg">{cert.title}</CardTitle>
                        {cert.status === "In Progress" && <Badge variant="outline">In Progress</Badge>}
                      </div>
                      <CardDescription>
                        {cert.provider} • {cert.date}
                      </CardDescription>
                    </div>
                  </div>
                  {cert.description && <p className="text-sm text-muted-foreground mt-3">{cert.description}</p>}
                </CardHeader>
              </Card>
            ))}
          </div>

          <Card className="border-2 border-primary/30 bg-primary/5">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <BookOpen className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle>Additional Ongoing Courses</CardTitle>
                  <CardDescription className="text-base italic">"Learning Never Stops"</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {ongoingCourses.map((course, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 bg-background rounded-lg">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 shrink-0" />
                    <div>
                      <h4 className="font-medium text-sm">{course.title}</h4>
                      <p className="text-xs text-muted-foreground">{course.provider}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
