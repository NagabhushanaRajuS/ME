import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Github, Linkedin, Mail, MapPin, Phone } from "lucide-react"

export function ContactSection() {
  return (
    <section id="contact" className="py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Let's <span className="text-primary">Connect</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              I'm always open to discussing new opportunities, collaborations, or just having a chat about technology
              and innovation.
            </p>
          </div>

          <Card className="border-2">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Get In Touch</CardTitle>
              <CardDescription className="text-base">
                Feel free to reach out through any of the following channels
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <a
                  href="mailto:nagabhushanaraju2003@gmail.com"
                  className="flex items-center gap-4 p-4 border border-border rounded-lg hover:border-primary/50 hover:bg-muted/50 transition-all group"
                >
                  <div className="p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                    <Mail className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Email</h3>
                    <p className="text-sm text-muted-foreground">nagabhushanaraju2003@gmail.com</p>
                  </div>
                </a>

                <a
                  href="tel:+916366434441"
                  className="flex items-center gap-4 p-4 border border-border rounded-lg hover:border-primary/50 hover:bg-muted/50 transition-all group"
                >
                  <div className="p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                    <Phone className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Phone</h3>
                    <p className="text-sm text-muted-foreground">+91-6366434441</p>
                  </div>
                </a>

                <div className="flex items-center gap-4 p-4 border border-border rounded-lg">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <MapPin className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Location</h3>
                    <p className="text-sm text-muted-foreground">Mysuru, Karnataka, India</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 border border-border rounded-lg">
                  <div className="flex gap-2 w-full justify-center">
                    <Button variant="outline" size="icon" asChild>
                      <a href="https://github.com/Nagabhushanaraju" target="_blank" rel="noopener noreferrer">
                        <Github className="h-5 w-5" />
                      </a>
                    </Button>
                    <Button variant="outline" size="icon" asChild>
                      <a href="https://linkedin.com/in/-nagabhushanarajus-" target="_blank" rel="noopener noreferrer">
                        <Linkedin className="h-5 w-5" />
                      </a>
                    </Button>
                    <Button variant="outline" size="icon" asChild>
                      <a href="mailto:nagabhushanaraju2003@gmail.com">
                        <Mail className="h-5 w-5" />
                      </a>
                    </Button>
                  </div>
                </div>
              </div>

              <div className="pt-6 text-center">
                <Button size="lg" asChild>
                  <a href="mailto:nagabhushanaraju2003@gmail.com">
                    <Mail className="mr-2 h-5 w-5" />
                    Send Me an Email
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="mt-12 text-center text-sm text-muted-foreground">
            <p>© 2026 Nagabhushana Raju S. Built with Next.js, React, and Tailwind CSS.</p>
            <p className="mt-2 italic">"Learning Never Stops"</p>
          </div>
        </div>
      </div>
    </section>
  )
}
