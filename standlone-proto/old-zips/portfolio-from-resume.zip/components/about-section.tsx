export function AboutSection() {
  return (
    <section id="about" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-8">
            About <span className="text-primary">Me</span>
          </h2>

          <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
            <p>
              I'm a motivated and adaptable software development enthusiast with a foundation in{" "}
              <span className="text-foreground font-medium">Machine Learning</span> and{" "}
              <span className="text-foreground font-medium">Data Visualization</span>. I possess strong problem-solving
              abilities, effective communication skills, and a creative approach to leveraging AI.
            </p>

            <p>
              With experience in building <span className="text-foreground font-medium">multimodal AI systems</span>,
              full-stack web applications, and data-driven solutions, I thrive in collaborative environments where I can
              continuously learn and grow. My technical journey spans from engineering data pipelines with ResNet and
              BERT to creating responsive web applications with modern frameworks.
            </p>

            <p>
              I'm eager to learn new technologies, expand my knowledge base, and contribute to innovative projects that
              make a real impact. Currently completing my B.E. in Computer Science & Engineering (Data Science) with an
              improving GPA of 7.2, demonstrating consistent upward growth.
            </p>
          </div>

          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2">7.2</div>
              <div className="text-sm text-muted-foreground">Current GPA</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2">15+</div>
              <div className="text-sm text-muted-foreground">Projects Built</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2">10+</div>
              <div className="text-sm text-muted-foreground">Certifications</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2">4</div>
              <div className="text-sm text-muted-foreground">Languages</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
