import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Code, Database, Wrench, Brain, Users, Globe } from "lucide-react"

const skillCategories = [
  {
    title: "Languages",
    icon: Code,
    skills: ["Python", "Java", "C", "HTML", "CSS", "JavaScript"],
  },
  {
    title: "Data & AI",
    icon: Brain,
    skills: ["Machine Learning", "EDA", "ADA", "Advanced Prompt Scripting", "Deep Learning", "NLP"],
  },
  {
    title: "Tools & Technologies",
    icon: Wrench,
    skills: ["Power BI", "Tableau", "Excel", "Docker", "Git", "GitHub", "MS Office Suite"],
  },
  {
    title: "Databases",
    icon: Database,
    skills: ["MySQL", "MongoDB", "PostgreSQL"],
  },
  {
    title: "Concepts",
    icon: Globe,
    skills: ["Version Control", "Parallel Programming", "RESTful APIs", "System Design"],
  },
  {
    title: "Soft Skills",
    icon: Users,
    skills: [
      "Problem Solving",
      "Teamwork",
      "Leadership",
      "Communication",
      "Project Management",
      "Adaptability",
      "Time Management",
    ],
  },
]

export function SkillsSection() {
  return (
    <section id="skills" className="py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Skills & <span className="text-primary">Expertise</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              A comprehensive toolkit built through academic learning, professional experience, and continuous
              self-improvement.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skillCategories.map((category, index) => {
              const Icon = category.icon
              return (
                <Card key={index} className="border-2 hover:border-primary/50 transition-colors">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <CardTitle className="text-lg">{category.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {category.skills.map((skill, skillIndex) => (
                        <Badge key={skillIndex} variant="secondary">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="mt-12 grid md:grid-cols-2 gap-6">
            <Card className="border-2">
              <CardHeader>
                <CardTitle>Languages</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">English</span>
                  <Badge>Proficient (C2)</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Kannada</span>
                  <Badge>Proficient (C2)</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Telugu</span>
                  <Badge>Native</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Hindi</span>
                  <Badge>Proficient (C2)</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardHeader>
                <CardTitle>Interests & Hobbies</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <h4 className="font-medium mb-2">Sports</h4>
                  <p className="text-sm text-muted-foreground">
                    Cricket, Football, Tennis, Carrom, Chess, Badminton, Swimming
                  </p>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Gaming</h4>
                  <p className="text-sm text-muted-foreground">
                    Assassin's Creed Mirage, Asphalt series, Clash of Clans
                  </p>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Creative</h4>
                  <p className="text-sm text-muted-foreground">Music, Singing, Content Creation</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
