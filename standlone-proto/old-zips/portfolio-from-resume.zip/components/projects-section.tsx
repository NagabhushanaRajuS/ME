import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Github, ExternalLink, Brain, Wallet, Car, Hand } from "lucide-react"

const projects = [
  {
    title: "Multimodal AI for Early Disease Detection",
    description:
      "Designed an AI-driven healthcare system leveraging multiple data types including medical images, EHRs, genetics, and symptoms. Applied deep learning and data fusion techniques to improve early-stage disease detection accuracy.",
    icon: Brain,
    tags: ["Python", "Deep Learning", "ResNet", "BERT", "Healthcare AI", "Data Fusion"],
    date: "Jun 2025 – Present",
    github: "https://github.com/Nagabhushanaraju",
  },
  {
    title: "Real-Time Sign Language Interpreter",
    description:
      "Built a multi-modal AI perception system for real-time sign language interpretation. Streamed results to a JavaScript frontend with dynamic UI overlays and modular architecture.",
    icon: Hand,
    tags: ["Python", "Computer Vision", "JavaScript", "Real-time Processing", "AI"],
    date: "Jun 2024 – Feb 2025",
    github: "https://github.com/Nagabhushanaraju",
  },
  {
    title: "Expense Tracker Web App",
    description:
      "Built a responsive and interactive web application to manage income, expenses, and monthly budgets. Implemented transaction management with category tags, timestamps, and visual charts for spending distribution.",
    icon: Wallet,
    tags: ["React", "JavaScript", "Charts", "Responsive Design", "Local Storage"],
    date: "Mar 2025 – Apr 2025",
    github: "https://github.com/Nagabhushanaraju",
  },
  {
    title: "Ola Electric Clone",
    description:
      "Created a full-stack web application inspired by Ola Electric's platform. Simulated features such as vehicle listings, test ride bookings, service scheduling, and charging station locators with an admin panel.",
    icon: Car,
    tags: ["Full-Stack", "React", "Node.js", "MongoDB", "Admin Panel"],
    date: "Feb 2025",
    github: "https://github.com/Nagabhushanaraju",
  },
]

export function ProjectsSection() {
  return (
    <section id="projects" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Featured <span className="text-primary">Projects</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              A collection of projects showcasing my skills in AI/ML, full-stack development, and data visualization.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {projects.map((project, index) => {
              const Icon = project.icon
              return (
                <Card
                  key={index}
                  className="group border-2 hover:border-primary/50 transition-all hover:shadow-lg hover:shadow-primary/10"
                >
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <div className="p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      <span className="text-xs text-muted-foreground">{project.date}</span>
                    </div>
                    <CardTitle className="text-xl group-hover:text-primary transition-colors">
                      {project.title}
                    </CardTitle>
                    <CardDescription className="text-base leading-relaxed">{project.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex flex-wrap gap-2">
                      {project.tags.map((tag, tagIndex) => (
                        <Badge key={tagIndex} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex gap-2 pt-2">
                      <Button size="sm" variant="outline" asChild>
                        <a href={project.github} target="_blank" rel="noopener noreferrer">
                          <Github className="h-4 w-4 mr-2" />
                          Code
                        </a>
                      </Button>
                      <Button size="sm" variant="outline" asChild>
                        <a href={project.github} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Live Demo
                        </a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="mt-8 p-6 bg-card border border-border rounded-lg">
            <h3 className="text-lg font-semibold mb-3">Additional Projects & Experiments</h3>
            <p className="text-muted-foreground leading-relaxed">
              Built multiple mini-projects exploring AI/ML, web development, automation, and systems programming. This
              includes chatbot prototypes using NLP and LangChain, interactive UI components with animations, automation
              workflows using n8n, GPU-accelerated projects with OpenMP and MPI, OAuth 2.0 authentication, automated
              email systems, and cryptographic owner-verification mechanisms demonstrating strong focus on security,
              scalability, and real-world deployment.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
